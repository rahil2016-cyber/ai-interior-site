
import formidable from "formidable";
import fs from "fs";
import { OpenAI } from "openai";

export const config = {
  api: {
    bodyParser: false,
  },
};

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export default async function handler(req, res) {
  const form = new formidable.IncomingForm();
  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ error: "Form parsing error" });

    const style = fields.style || "Modern";

    // Prompt construction for DALL·E
    const prompt = `Redesign this room in a ${style} interior design style.`;

    try {
      const image = await openai.images.generate({
        model: "dall-e-3",
        prompt,
        n: 1,
        size: "1024x1024",
      });

      return res.status(200).json({ image_url: image.data[0].url });
    } catch (error) {
      return res.status(500).json({ error: "OpenAI error", details: error.message });
    }
  });
}
